import Vue from '.src/vue.js'

export default Vue.component(
  {
    name: 'Note',
    template: '#note-template',
    components: {},
    props: {
      noteData: Object,
      title: ''
    },
    data() {
      return {
        message: 'fuck',
        content: '',
        title: '',
        gotClicked: false
      }
    },
    methods: {
      handleClick() {
        this.title = 'i got clicked'
       this.gotClicked = true;
        console.log(this.title);
      }
    },
    watch: {},
    computed: {},

    created() {},
    mounted() {},
    updated() {},
    destroyed() {}
})